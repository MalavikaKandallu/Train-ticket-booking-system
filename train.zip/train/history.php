<html>
<head>
<title>PAYMENT</title>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url(img1.jpg);"color:black", class="body">
<div class="menu-bar">
<ul>
<p color:"black"> BOOKING HISTORY</p>
<li><a href="main.html" style="color:white">BOOK TICKET</a></li>
<li><a href="payment.php" style="color:white">TICKET PAYMENT</a></li>
<li><a href="history.php" style="color:white">BOOKING HISTORY</a></li>
<li><a href="logina.html" style="color:white">LOG OUT</a></li>
</ul>
</div>
<br><br><br><br>

<form action="successful.html">
<center>
<table class="table">
                   
                 
<th class="th">Name:</th>
<th class="th">Date of journey:</th>
<th class="th">From:</th>
<th class="th">To:</th>
<th class="th">Train name:</th>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "train";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Name,College_name,university, university1,courses FROM home";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
             

                $stname=$row['Name'];
                $sub1=$row['College_name'];
                $sub2=$row['university'];
                $sub3=$row['university1'];
                $sub4=$row['courses'];
                echo"
                <tr class='td'>

                <td class='td'>$stname</td>
                  <td class='td'>$sub1</td>
        <td class='td'>$sub2</td>
        <td class='td'>$sub3</td>
        <td class='td'>$sub4</td>


                </tr>";

        }
 
  }

else {
 echo "0 results";
}
$conn->close();
?>

</table>

</center>
</form>
</body>
</html>