-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2022 at 07:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `train`
--

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Register_number` varchar(100) NOT NULL,
  `Mobile_number` varchar(100) NOT NULL,
  `College_name` varchar(100) NOT NULL,
  `university` varchar(100) NOT NULL,
  `university1` varchar(100) NOT NULL,
  `courses` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `Name`, `Register_number`, `Mobile_number`, `College_name`, `university`, `university1`, `courses`) VALUES
(1, 'm', '', '123', '', '', '', ''),
(13, 'Charoolatha Moorthy', '14/252,periyar pathai', '9150856403', '2022-05-19', 'CHENNAI EGMORE - MS', 'CHENNAI EGMORE - MS', 'MAS NZM RAJDHANI (12433)');

-- --------------------------------------------------------

--
-- Table structure for table `logina`
--

CREATE TABLE `logina` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logina`
--

INSERT INTO `logina` (`username`, `password`) VALUES
('charoo', 'charoo'),
('swetha', '4321'),
('mithra', 'mithra'),
('malavika', 'malavika'),
('pavithra', '1234'),
('', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
