<?php    
 
    $name=$_POST['name'];  
        $rno=$_POST['rno'];  
$mno=$_POST['mno'];  
        $cname=$_POST['cname'];
$university=$_POST['university'];  
$university1=$_POST['university1'];
        $courses=$_POST['courses'];  
    $con=mysqli_connect('localhost','root','') or die(mysql_error());  
    mysqli_select_db($con,'train') or die("cannot select DB");  
 

    $sql="INSERT INTO home(Name,Register_number,Mobile_number,College_name,university, university1,courses) VALUES('$name','$rno','$mno','$cname','$university','$university1','$courses')";  
 
    $result=mysqli_query($con,$sql);  
        if($result==true){  
                       
  header("refresh:1;url=payment.php");
    } else {  
    echo "Failure!";  
    }  
 

 
 
?>  